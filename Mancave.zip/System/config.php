<?php
// config.php
$host = "localhost";
$user = "root";
$pass = "";
$db = "Kanto_Db"; // <-- This has been updated from "af_system"

$conn = mysqli_connect($host, $user, $pass, $db);

if (!$conn) {
die("Connection failed: " . mysqli_connect_error());
}

return $conn;
?>