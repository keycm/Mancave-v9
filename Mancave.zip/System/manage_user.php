<?php
session_start();
include 'config.php';
header('Content-Type: application/json');

// Security Check
if (!isset($_SESSION['role']) || $_SESSION['role'] !== 'admin') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit();
}

$action = $_REQUEST['action'] ?? '';

try {
    switch ($action) {
        // --- ADD NEW USER ---
        case 'add':
            $username = $_POST['username'] ?? '';
            $email = $_POST['email'] ?? '';
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? 'user';

            if (empty($username) || empty($email) || empty($password) || empty($role)) {
                throw new Exception('Please fill in all required fields.');
            }
            
            // Basic Validation
            if (strlen($password) < 8) {
                 throw new Exception('Password must be at least 8 characters.');
            }
            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                 throw new Exception('Invalid email format.');
            }

            // Check for Duplicate Email
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                throw new Exception('An account with this email already exists.');
            }
            $stmt->close();
            
            // Hash Password & Insert
            $password_hash = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $email, $password_hash, $role);
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception('Failed to create user: ' . $stmt->error);
            }
            $stmt->close();
            break;

        // --- UPDATE USER ---
        case 'update':
            $id = $_POST['id'] ?? 0;
            $username = $_POST['username'] ?? '';
            $email = $_POST['email'] ?? '';
            $role = $_POST['role'] ?? 'user';
            $new_pass = $_POST['password'] ?? '';

            if (empty($id) || empty($username) || empty($email) || empty($role)) {
                throw new Exception('Please fill in all required fields.');
            }
            
            // Check for Duplicate Email (excluding self)
            $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
            $stmt->bind_param("si", $email, $id);
            $stmt->execute();
            if ($stmt->get_result()->num_rows > 0) {
                throw new Exception('This email is already in use by another account.');
            }
            $stmt->close();

            // Update logic (with or without password change)
            if (!empty($new_pass)) {
                if (strlen($new_pass) < 8) throw new Exception('Password must be at least 8 characters.');
                $hash = password_hash($new_pass, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET username=?, email=?, role=?, password=? WHERE id=?");
                $stmt->bind_param("ssssi", $username, $email, $role, $hash, $id);
            } else {
                $stmt = $conn->prepare("UPDATE users SET username=?, email=?, role=? WHERE id=?");
                $stmt->bind_param("sssi", $username, $email, $role, $id);
            }
            
            if ($stmt->execute()) {
                echo json_encode(['success' => true]);
            } else {
                throw new Exception('Failed to update user: ' . $stmt->error);
            }
            $stmt->close();
            break;

        // --- DELETE USER (Move to Trash) ---
        case 'delete':
            $id = $_POST['id'] ?? 0;
            if (empty($id)) throw new Exception('Invalid user ID.');
            if ($id == $_SESSION['user_id']) throw new Exception('You cannot delete your own account.');

            // 1. Fetch User Data
            $res = $conn->query("SELECT * FROM users WHERE id=$id");
            if ($row = $res->fetch_assoc()) {
                // 2. Prepare Trash Data
                $trashName = $row['username'] . '|' . json_encode($row);
                
                // 3. Insert into Trash
                $stmt = $conn->prepare("INSERT INTO trash_bin (item_id, item_name, source, deleted_at) VALUES (?, ?, 'users', NOW())");
                $stmt->bind_param("is", $id, $trashName);
                $stmt->execute();
                $stmt->close();
                
                // 4. Delete User from Main Table
                $conn->query("DELETE FROM users WHERE id=$id");
                echo json_encode(['success' => true]);
            } else {
                throw new Exception("User not found");
            }
            break;

        default:
            throw new Exception('Invalid action.');
    }

} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}
$conn->close();
?>