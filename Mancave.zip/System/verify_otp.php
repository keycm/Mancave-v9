<?php
session_start();
include 'config.php';

$email = $_POST["email"] ?? $_GET["email"] ?? $_SESSION["otp_email"] ?? null;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    
    $otp = $_POST["otp"] ?? '';
    $email = $_POST["email"] ?? '';

    if (empty($otp) || empty($email)) {
        $_SESSION['error_message'] = "Please provide both email and OTP.";
        header("Location: verify_otp.php" . ($email ? "?email=" . urlencode($email) : ""));
        exit;
    }

    // Step 1: Validate email and get user
    $sql = "SELECT * FROM users WHERE email = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        $_SESSION['error_message'] = "User not found.";
        header("Location: verify_otp.php?email=" . urlencode($email));
        exit;
    }

    // Step 2: Check if already activated
    if (empty($user["account_activation_hash"])) {
         $_SESSION['success_message'] = "Account is already activated. You can log in.";
         header("Location: index.php"); // Redirect to login
         exit;
    }

    // Step 3: Check expiry
    if (strtotime($user["reset_token_expires_at"]) <= time()) {
        $_SESSION['error_message'] = "OTP has expired. Please register again or request a new one (feature not implemented).";
        // Note: You might want to add a "resend OTP" feature later
        header("Location: verify_otp.php?email=" . urlencode($email));
        exit;
    }
    
    // Step 4: Check OTP
    if ($user["account_activation_hash"] !== $otp) {
        $_SESSION['error_message'] = "Invalid OTP. Please try again.";
        header("Location: verify_otp.php?email=" . urlencode($email));
        exit;
    }

    // Step 5: Activate account!
    $sql_update = "UPDATE users
                   SET account_activation_hash = NULL,
                       reset_token_expires_at = NULL
                   WHERE id = ?";

    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("i", $user["id"]);
    $stmt_update->execute();

    // Success! Redirect to login with a success message.
    unset($_SESSION['otp_email']);
    $_SESSION['success_message'] = "Account activated successfully! You can now log in.";
    header("Location: index.php?login=1"); // ?login=1 might auto-open login modal
    exit;

}

// unset any old signup error messages
if (isset($_SESSION['error_message']) && $_GET_['from_signup'] ?? false) {
    unset($_SESSION['error_message']);
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Verify Account</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      background-color: #e5e5e5;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
    }
    .verify-container {
      background-color: white;
      padding: 2.5rem;
      border-radius: 1rem;
      box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.1);
      width: 100%;
      max-width: 450px;
    }
    h1 {
      text-align: center;
      font-weight: 700;
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>
  <div class="verify-container">
    <h1>Verify Your Account</h1>
    <p class="text-center text-muted mb-3">An OTP has been sent to <strong><?php echo htmlspecialchars($email ?? 'your email'); ?></strong>. Please enter it below.</p>
    
    <?php if (isset($_SESSION['success_message'])): ?>
        <div class="alert alert-success">
            <?php echo $_SESSION['success_message']; unset($_SESSION['success_message']); ?>
        </div>
    <?php endif; ?>
    
    <?php if (isset($_SESSION['error_message'])): ?>
        <div class="alert alert-danger">
            <?php echo $_SESSION['error_message']; unset($_SESSION['error_message']); ?>
        </div>
    <?php endif; ?>

    <form method="post" action="verify_otp.php">
      <input type="hidden" name="email" value="<?= htmlspecialchars($email ?? '') ?>">

      <div class="mb-3">
        <label for="otp" class="form-label">Enter 6-Digit OTP</label>
        <input type="text" class="form-control" id="otp" name="otp" required 
               pattern="\d{6}" title="Please enter a 6-digit number" maxlength="6"
               oninput="this.value=this.value.replace(/[^0-9]/g,'')">
      </div>
     
      <button type="submit" class="btn btn-dark w-100">Verify Account</button>
    </form>
    
    <div class="text-center mt-3">
        <p class="text-muted small">Didn't get the code? <a href="signup.php">Register again</a> to get a new code.</p>
        <p class="text-muted small">Already verified? <a href="index.php?login=1">Log in here</a>.</p>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>