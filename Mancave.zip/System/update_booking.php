<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] !== "POST") { 
    header('Location: admin.php'); 
    exit; 
}

$id = isset($_POST['id']) ? intval($_POST['id']) : 0;
$action = $_POST['action'] ?? '';

if ($id <= 0) exit("Invalid ID");

function notifyUser($conn, $id, $msg) {
    $q = mysqli_query($conn, "SELECT user_id FROM bookings WHERE id=$id");
    if ($q && $r = mysqli_fetch_assoc($q)) {
        $uid = $r['user_id'];
        $msg = mysqli_real_escape_string($conn, $msg);
        mysqli_query($conn, "INSERT INTO notifications (user_id, message) VALUES ($uid, '$msg')");
    }
}

switch ($action) {
    case 'approved':
        mysqli_query($conn, "UPDATE bookings SET status='approved' WHERE id=$id");
        notifyUser($conn, $id, "Your booking has been approved.");
        break;
        
    case 'rejected':
        mysqli_query($conn, "UPDATE bookings SET status='rejected' WHERE id=$id");
        notifyUser($conn, $id, "Your booking was rejected.");
        break;
        
    case 'completed':
        // Force lowercase 'completed'
        mysqli_query($conn, "UPDATE bookings SET status='completed' WHERE id=$id");
        notifyUser($conn, $id, "Your booking has been marked as completed. Thank you!");
        break;
        
    case 'delete':
        // Move to Trash Logic
        $query = mysqli_query($conn, "SELECT * FROM bookings WHERE id=$id");
        if ($row = mysqli_fetch_assoc($query)) {
            $displayName = "Booking: " . $row['service'] . " - " . $row['full_name'];
            $trashData = $displayName . '|' . json_encode($row);
            $trashDataSafe = mysqli_real_escape_string($conn, $trashData);
            
            $insertTrash = "INSERT INTO trash_bin (item_id, item_name, source, deleted_at) 
                            VALUES ($id, '$trashDataSafe', 'bookings', NOW())";
            
            if (mysqli_query($conn, $insertTrash)) {
                mysqli_query($conn, "UPDATE bookings SET deleted_at=NOW() WHERE id=$id");
            }
        }
        break;
}
?>